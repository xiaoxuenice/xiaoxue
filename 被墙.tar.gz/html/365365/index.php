<?php
$the_host = $_SERVER['HTTP_HOST'];
Header("HTTP/1.1 303 Moved Permanently");
Header("Location: http://djdj.com/?search=".$the_host);
?>
