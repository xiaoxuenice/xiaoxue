<?php
$hehe = $_GET[ 'search' ];
$he=str_replace("www.","",$hehe);
Header("HTTP/1.1 303 Moved Permanently");
Header("Location: http://djdj.com/".$he)
?>
