<?php
Header("HTTP/1.1 303 Moved Permanently");
Header("Location: http://www-dbet365.com");
?>
