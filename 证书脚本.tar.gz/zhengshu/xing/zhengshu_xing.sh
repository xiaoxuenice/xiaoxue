#!/bin/bash
cd /zhengshu/xing
unzip(){
for i in `ls |grep zip`;do unzip $i;done
}
Chkey(){
for i in `ls |grep key`;do c=`echo $i|awk -F'[_.]' '{print $2"."$3}'` && mv $i ${c}.key ;done
}
Chcrt(){
for i in `ls |grep crt`;do c=`echo $i|awk -F'[_.]' '{print $2"."$3}'` && mv $i ${c}.crt ;done
}
Chall(){
for i in `ls|grep crt|awk -F'.' '{print $1"."$2}'`;do cp /usr/local/nginx/kis/1881305.com.conf ${i}.conf && sed -i "s/1881305\.com/$i/g" ${i}.conf;done
}
Mv(){
mv  *crt *key *conf /shangchuan
}
Chkey
Chcrt
Chall
Mv
