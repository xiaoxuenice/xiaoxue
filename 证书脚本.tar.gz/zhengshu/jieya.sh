#!/bin/bash
rm -rf /shangchuan/*
a(){
for i in `ls |grep zip`;do unzip $i;done
}
b(){
for i  in `ls |grep '\*\|STAR'`;do mv $i xing;done
}
c(){
for i  in `ls |grep crt`;do mv $i gang;done
}
d(){
for i  in `ls |grep key`;do mv $i gang;done
}
a
b
c
d
sleep 2
sh xing/zhengshu_xing.sh
sleep 3
sh gang/zhengshu_gang.sh

